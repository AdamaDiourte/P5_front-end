/*----------------------Liste des produits choisis ------------------------------*/

// let produitChoisis = ['table 1', 'table 2', 'table 3', 'table 4', 'table 5']

// let produit = ""

// for( let i= 0; i < produitChoisis.length; i++){
//     produit+= produitChoisis[i] + "\n";
// }

// alert("Les produits que vous avez choisis sont les suivants : " + "\n" + produit)
// let panier = ['table 1', 'table 2', 'table 3', 'table 4', 'table 5'];
// let panierListe = ""

// for( i = 0; i < panier.length; i++){
//     panierListe+= panier[i] + "\n"; 
// }

// alert("Votre panier contient les produits suivants : " + "\n" + panierListe)

/*-----------------------------------------------------------------------------*/


// let panier = [];
// let achat = panier.push('table 1', 'table 2', 'table 3', 'table 4', 'table 5');

// let produitsAchete = ""
// for( let i = 0; i < panier.length; i++){
//     produitsAchete+= + "\n" + panier[i] ;
// }
// alert("Récapitulatif de votre commande : " + "\n" + panier)

/*-----------------------------------------------------------------------------*/

/*---------------------CREATION DE LA PAGE DE DESCRIPTION DES PRODUITS---------------*/


/*------------Fonction asynchrone d'affichage des articles récupérés depuis l'API--------------*/ 
// async function main(){
//     const data = await recupTousLesArticlesAPI()
//     afficherTousLesArticles(tousLesArticles)
//     for(article of tousLesArticles){
//         afficherToutesLesArticles(tousLesArticles)
//     }
// }


/*-----------Fonction de récupération de toutes les artciles depuis l'API---------*/
const loadata = (data) =>{
    data.forEach((element, index) => {
        let className = ""// ajouter la classe
        let html = ""// ajouter l'article 
    });
}

// const getProductList = () => {
//   fetch("http://localhost:3000/api/furniture")
//     .then((response) => response.json())
//     .then((data) => {
//       loadDataInDom(data);
//       console.log(response)
//     })
//     .catch((error) => {
//       console.log("error", error);
//     });
// };


fetch("http://localhost:3000/api/furniture")
  .then(function(res) {
    if (res.ok) {
      return res.json();
    }
  })
  .then(function(value) {
    console.log(value);
  })
  .catch(function(err) {
    // Une erreur est survenue
  });



// function recupTousLesArcticlesAPI(){
// return fetch("http://localhost:3000/api/furniture")
//         .then(function(httpBodyResponse){
//            return httpBodyResponse.json()
//         })

//         .then(function(tousLesArticles){
            
//         })

//         .catch(
//             function(erreur){
//             alert(erreur);
//         })

// }

// console.log(tousLesArticles);


// function afficherTousLesArticles(){
//     document.getElementsByClassName(".main-container")
     
// }



/*------------------------------------------------------------------------------*/ 
// class Article{
//     constructor(jsonArticle){
//         jsonArticle && Object.assign(this, jsonArticle)

//         this.varnish = jsonArticle.varnish;
//         this.id = jsonArticle.id;
//         this.name = jsonArticle.name;
//         this.price = jsonArticle.price;
//         this.description = jsonArticle.description;
//         this.imageUrl = jsonArticle.imageUrl;

//     }



(async function main(){
    const articles = await getArticles()

    for( article of articles){
        displayArticle(article)
        
    }
})()


async function getArticles(){
    return fetch("http://localhost:3000/api/furniture") /*Depuis ce lien, la fonction "fetch" récupère les articles*/
        .then (function(httpBodyResponse){
            return httpBodyResponse.json()          /*Fonction qui stock et convertit ensuite en JSON le fichier récupéré depuis l'API*/
        })

        .then (function(articles){            /*Fonction qui permet de renommer les fichiers récupérés et les retournes partout où ils osnt appelés*/
            return articles
            
        }) 

        .catch (function(error){             /*Fonction qui affiche le message signalant un problème de téléchargement*/
            alert("Une erreur est survenue lors du chargement des fichiers depuis l'API")
        })
}

function displayArticle(article){

    document.getElementById("container").innerHTML +=`
    
        <div class="card">
                <img class="img-card" src ="${article.imageUrl}"  >
                <div class="div-article-titre-prix">
                    <h4 class="titre-article"> ${article.name}</h4>
                    <span class="lead">Prix: ${article.price / 100}.00 € </span>
                </div>
                <a href="html/article.html?${article._id}"><button class="btn btn-secondary btn-modif-1">Voir plus</button></a>
        </div>
        `
   
}


const idUrlArticle = window.location.search   /*Récupérer l'ID de l'article depuis l'URL*/

let recupIdSeul = idUrlArticle.slice(1);   /*Extraitre l'ID de l'article sans le point d'interrogation*/ 

// let affichArtSelect = fetch("http://localhost:3000/api/furniture/${recupIdSeul}")


// let articleSelectionne =  fetch (){
    
//     .then(function(){
//          function displayArticle(article){

//     document.getElementById("container").innerHTML +=`

//             <div class="card ">
//                 <img src="${article.imageUrl}" class="img-card" >
//                 <div class="div-article-titre-prix">
//                     <h4 class="titre-article">${article.name}</h4>
//                     <span class="lead">Prix: ${article.price / 100}.00 €</span>
//                 </div>
//                 <figcaption class="description">${article.description}</figcaption>
//                 <div class="div-slect-btn">
//                     <div class="div-select">
//                         <label class="titre-label" for="">Vernisage</label>
//                         <select class="champ-selection champ-selection-modif-1" id="monselect">
//                             <option value="1"selected>Sans vernis</option>
//                             <option value="2" >Vernis sombre</option>
//                             <option value="3">Vernis clair</option>
//                         </select>
//                     </div>
//                     <a href="panier.html"><button class="btn btn-secondary btn-modif-1">Acheter</button></a>
                                
//                 </div>
//             </div>
        
//         `
   
// }
//     })
//    } /*Affichage de l'article sélectionné*/ 





// (async function main(){
//     const articles = await getArticles()

//     for( article of articles){
//         displayArticle(article)
        
//     }
// })()

// async function getArticles(){
//     return fetch("http://localhost:3000/api/furniture")
//         .then (function(httpBodyResponse){
//             return httpBodyResponse.json()
//         })

//         .then (function(articles){
//             return articles

//         }) 

//         .catch (function(error){
//             alert("error")
//         })
// }

// function displayArticle(article){

//     const templateElmt = document.querySelector(".templateArticle")
//     const cloneElmt = document.importNode(templateElmt.content, true)

//     cloneElmt.querySelector(".img-card").src = article.imageUrl
//     cloneElmt.querySelector(".titre-article").textContent = article.name
//     cloneElmt.querySelector(".description").textContent = article.description
//     cloneElmt.querySelector(".lead").textContent = `${article.price / 100}.00 €`

//     // Créer une div avec le tableau des choix 

//     document.querySelector(".templateArticle").appendChild (cloneElmt)
   
// }





/*---------------------------------------------------*/ 



/*(async function main(){
    const articles = await getArticles()

    displayArticle(article)
})()


async function getArticles(){
    return fetch("http://localhost:3000/api/furniture    http://localhost:3000/api/furniture/5be9cc611c9d440000c1421e") /*Depuis ce lien, la fonction "fetch" récupère les articles*/
        // .then (function(httpBodyResponse){
        //     return httpBodyResponse.json()          /*Fonction qui stock et convertit ensuite en JSON le fichier récupéré depuis l'API*/
        // })

        // .then (function(articles){            /*Fonction qui permet de renommer les fichiers récupérés et les retournes partout où ils osnt appelés*/
        //     return articles
            
        // }) 

        // .catch (function(error){             /*Fonction qui affiche le message signalant un problème de téléchargement*/
        //     alert("Une erreur est survenue lors du chargement des fichiers depuis l'API")
        // })
// }




(async () => {
    const idArticleDansURL = window.location.search   /*Récupérer l'ID de l'article depuis l'URL*/
    var recupIdSeul = idArticleDansURL.slice(1);   /*Extraitre l'ID de l'article sans le point d'interrogation*/ 
    let articleVoirPlus = await leFetchArt(recupIdSeul)

    hydratePage(productData)
})()

    
    //   const productId = getProductId()
    
    


async function leFetchArt (){
    return fetch(`http://localhost:3000/api/furniture?/${recupIdSeul}`)
        // return fetch(`${apiUrl}/api/teddies/${productId}`)
        .catch((error) => {
        console.log(error)
        })
        .then((httpBodyResponse) => httpBodyResponse.json())
        .then((productData) => productData)

    }





function displayArticle(article){

    document.getElementById("container").innerHTML +=`
    
        <div class="card">
                <img class="img-card" src ="${article.imageUrl}"  >
                <div class="div-article-titre-prix">
                    <h4 class="titre-article"> ${article.name}</h4>
                    <span class="lead">Prix: ${article.price / 100}.00 € </span>
                </div>
                <a href="html/article.html?${article._id}"><button class="btn btn-secondary btn-modif-1">Voir plus</button></a>
        </div>
        `
   
}



/*-----------------------------AUTRE METHODE -----DEBUT--------*/ 
const recupUrlArticle = window.location.search   //Récupérer l'ID de l'article depuis l'URL
const recupIdArticle = recupUrlArticle.slice(1);   //Extraitre l'ID de l'article sans le point d'interrogation

getProduct(recupIdArticle);

async function getProduct(recupIdArticle) {
  const articleCliquer = await fetch(`http://localhost:3000/api/furniture/${recupIdArticle}`);
  const article = await articleCliquer.json();
  return article;
}

/*-----------------------------AUTRE METHODE -----FIN--------*/ 
