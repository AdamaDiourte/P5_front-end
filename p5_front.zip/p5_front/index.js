/*-----Début----Fonction globale pour l'affichage des produits sur la page d'accueil---------*/ 

(async function main(){

    const articles = await getArticles()  /*Les articles récupérés dans l'API sont stockés dans la constate "articles*/  
    
    for( article of articles){
        displayArticle(article)           /*Une boucle "for" qui affiche chaque "article" contenu dans la "const articles" */
        
    }
})()

/*-----Fin----Fonction globale pour l'affichage des produits sur la page d'accueil---------*/ 


/*-----Début----Fonction pour récupérer les produits depuis l'API---------*/ 

async function getArticles(){
    return fetch("http://localhost:3000/api/furniture") /*Depuis ce lien, la fonction "fetch" récupère les articles*/
        .then (function(httpBodyResponse){
            return httpBodyResponse.json()          /*Fonction qui stock et convertit ensuite en JSON le fichier récupéré depuis l'API*/
        })

        .then (function(articles){            /*Fonction qui permet de renommer les fichiers récupérés et les retournes partout où ils sont appelés*/
            return articles

        }) 

        .catch (function(error){             /*Fonction qui affiche le message signalant un problème de téléchargement*/
            alert("Une erreur est survenue lors du chargement des fichiers depuis l'API")
        })
}

/*-----Fin----Fonction pour récupérer les produits depuis l'API---------*/ 


/*-----Début----Fonction qui permet d'afficher les produits récupérés dans l'API---------*/ 

// function displayArticle(article){

//     const templateElmt = document.querySelector(".templateArticle")
//     const cloneElmt = document.importNode(templateElmt.content, true)

//     cloneElmt.querySelector(".img-card").src = article.imageUrl
//     cloneElmt.querySelector(".titre-article").textContent = article.name
//     cloneElmt.querySelector(".lead").textContent = `${article.price / 100}.00 €`

//     document.querySelector(".templateArticle").appendChild (cloneElmt)
   
// }

function displayArticle(article){

    document.querySelector(".div-card").innerHTML +=`
    
        <div class="card col-md-5">

            <img class="img-card" src ="${article.imageUrl}">

            <div class="div-article-titre-prix">
                <h4 class="titre-article"> ${article.name}</h4>
                <span class="lead">Prix: ${article.price / 100}.00 € </span>
            </div>

            <a href="/P5_front-end/html/article.html?id=${article._id}"><button class="btn btn-secondary btn-modif-1">Voir plus</button></a>

        </div>
    `;
   
}

/*-----Fin----Fonction qui permet d'afficher les produits récupérés dans l'API---------*/